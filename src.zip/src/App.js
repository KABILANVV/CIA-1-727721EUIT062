import React from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Read from './Components/Read'
import Update from './Components/Update'
import Create from './Components/Create'
import "./App.css";

const App = () => {
  return (
    <BrowserRouter>
    <Routes>
    <Route exact path="/" element={<Create/>}></Route>
    <Route exact path="/Read" element={<Read/>}></Route>
    <Route exact path="/Update" element={<Update/>}></Route>
    </Routes>
    </BrowserRouter>
  )
}

export default App