import React from 'react'
import { FormGroup,FormControl,InputLabel,Input,makeStyles,Button,FormControlLabel,Checkbox,FormLabel,Typography } from '@material-ui/core'
import {useForm} from 'react-hook-form';

// return (
// <FormGroup>
// <FormLabel component="legend">Create Contact</FormLabel>
// <FormControl>
// <InputLabel>Full Name</InputLabel>
// <Input placeholder='Enter Full name'></Input>
// </FormControl>
// <FormControl>
// <InputLabel>Email</InputLabel>
// <Input placeholder='Email'></Input>
// </FormControl>
// <FormControl>
// <InputLabel>Mobile Number</InputLabel>
// <Input placeholder='Enter Mobile Number'></Input>
// </FormControl>
// <FormControl>
// <InputLabel>Date of Birth</InputLabel>
// <Input placeholder='DoB'></Input>
// </FormControl>
// </FormGroup>
const Create = () => {

function App() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  return (
    <form onSubmit={handleSubmit((data) => console.log(data))}>
      <input {...register('firstName')} />
      <input {...register('lastName', { required: true })} />
      {errors.lastName && <p>Last name is required.</p>}
      <input {...register('age', { pattern: /\d+/ })} />
      {errors.age && <p>Please enter number for age.</p>}
      <input type="submit" />
    </form>
  );
}

}

export default Create