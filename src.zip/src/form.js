import React from "react";
import "./App.css";
class RegisterForm extends React.Component {
  constructor() {
    super();
    this.state = {
      fields: {},
      errors: {},
    errors1 : {},
    errors2 :{},
    errors3 : {},
    errors4 : {},
    }
    

    this.handleChange = this.handleChange.bind(this);
    this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);

  };

  handleChange(e) {
    let fields = this.state.fields;
    fields[e.target.name] = e.target.value;
    this.setState({
      fields
    });
  

  }

  submituserRegistrationForm(e) {
    console.log(this.validateForm());
    
    e.preventDefault();
    if (this.validateForm()) {
        console.log(this.state);
        let fields = {};
        fields["username"] = "";
         fields["emailid"] = "";
         fields["password"] = "";
        this.setState({fields:fields});
        console.log(this.state);
        alert("Form submitted");
    }
    
}
// Pass(){
    
//     let fields = this.state.fields;
    
//       elem.innerHTML="Hi";
// }
validateForm() {
    
    let fields = this.state.fields;
    let errors = {};
    let errors1 = {};
    let errors2 = {};
    let errors3 = {};
    let errors4 = {};
    let formIsValid = true;
    
    
    if (!fields["username"]) {
      formIsValid = false;
      errors["username"] = "*Please enter your username.";
    }
    
    if (typeof fields["username"] !== "undefined") {
      if (!fields["username"].match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["username"] = "*Please enter alphabet characters only.";
      }
    }

    if (!fields["emailid"]) {
        formIsValid = false;
      errors["emailid"] = "*Please enter your email-ID.";
    }

    if (typeof fields["emailid"] !== "undefined") {
    //     //regular expression for email validation
      var pattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
      if (!pattern.test(fields["emailid"])) {
        formIsValid = false;
        errors["emailid"] = "*Please enter valid email-ID.";
    }
}


if (!fields["password"]) {
    formIsValid = false;
    errors["password"] = "*Please enter your password.";
}

if (typeof fields["password"] !== "undefined") {
    
    let caps, small, num, specialSymbol;
    caps = (fields["password"].match(/[A-Z]/g) || []).length;
      small = (fields["password"].match(/[a-z]/g) || []).length;
      num = (fields["password"].match(/[0-9]/g) || []).length;
      specialSymbol = (fields["password"].match(/\W/g) || []).length;
      if (caps > 0 && small> 0 && num > 0 &&  specialSymbol > 0) {
        
    errors1["password"] = "Password is Very Strong";
    formIsValid = false;
      } 
      else if (( small >0 && num > 0 &&  specialSymbol > 0) ||(caps > 0  && num > 0 &&  specialSymbol > 0) || (caps > 0 && small > 0 &&   specialSymbol > 0) ||(caps> 0 && small > 0 && num > 0)) {
        
         errors2["password"] = "Password is Strong";
         formIsValid = false;
      } 
      else if (( small > 0 && num> 0) ||( num > 0 &&  specialSymbol> 0) || (caps> 0 && small > 0 ) ||(caps> 0  && num > 0) || (caps > 0 &&   specialSymbol > 0) || (small > 0 &&  specialSymbol > 0)) {
        
    errors3["password"] = "Password is Good";
    formIsValid = false;
      } 
      else if (caps > 0 || small > 0  || num > 0 ||  specialSymbol > 0) {
        
    errors4["password"] = "Password is Weak";
    formIsValid = false;

      }
    
        
    
    } 
       
    this.setState({
      errors: errors,
      errors1: errors1,
      errors2: errors2,
      errors3: errors3,
      errors4: errors4,

      
    });
    return formIsValid;


  }



render() {
  return (
      <div id="main-registration-container">
      <div id="register">
      <center>
      <div><h3><u>Register Here</u></h3></div>
      <form method="post"  name="userRegistrationForm"  onSubmit= {this.submituserRegistrationForm} >
      <label>Name</label>
      <input type="text" name="username" value={this.state.fields.username} onChange={this.handleChange} />
      <div className="errorMsg">{this.state.errors.username}</div>
      <label>Email ID:</label>
      <input type="text" name="emailid" value={this.state.fields.emailid} onChange={this.handleChange}  />
      <div className="errorMsg">{this.state.errors.emailid}</div>
      <label>Password</label>
      <input type="password" name="password" value={this.state.fields.password} onChange={this.handleChange} />
      <div className="errorMsg1">{this.state.errors1.password}</div>
      <div className="errorMsg2">{this.state.errors2.password}</div>
      <div className="errorMsg3">{this.state.errors3.password}</div>
      <div className="errorMsg4">{this.state.errors4.password}</div>

      <input type="submit" className="button"  value="Register"/>
      </form>
      </center>
  </div>
</div>

    );
}


}

export default RegisterForm